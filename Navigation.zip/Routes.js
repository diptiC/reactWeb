import React from "react";
import { BrowserRouter as Router, Switch, Route } from "react-router-dom";

class contact extends React.Component {
  render() {
    <Router>
      return <h1> contact</h1>
    </Router>;
  }
}
export default contact;
