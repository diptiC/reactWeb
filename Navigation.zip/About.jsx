import React, { Component } from "react";
import "./About.css";
import "./General.css";
import Image from "react-bootstrap/Image";
import { StyleSheet, Text, View } from "react-native";
import imgSrc from "./components/images/aboutUsPage/aboutUs.png";
import homeIcon from "./icons/home.png";
import {
  BrowserRouter as Router,
  NavLink,
  Switch,
  Route
} from "react-router-dom";
import Breadcrumb from "react-bootstrap/Breadcrumb";

//class about extends Component {
export default class about extends Component {
  render() {
    return (
      <div>
        <div className="container">
          <hr color="#3ed8d8" />
          <div className="banner">
            <div className="textClass">
              <h1 className="headerClass">About Us</h1>
              <br />
              <Text>
                Physics can seem very daunting.both for the teacher to convey
                and for the student to absorb...But we are here to help.Less
                than a mile from this beach in Miramar, Goa, a unique product
                was launched aimed at making the process more enjoyable using
                animation and interactivity. <br />
                <br />
                Vivaphysics in an endeavour aimed at encouraging students to
                pursue careers with the use of advanced technology skills and
                domain knowwledge of Physics of its developers in helping
                students gain an understanding of the concepts in Physics.The
                goal is getting students interested early in Physics and to shed
                their fears about the subject. <br />
                <br />
              </Text>
            </div>
            <text className="textClass2">
              Vivaphysics guides you through the entire course, step by step, in
              away that you will find it easier to retain the knowledge.Beside
              concepts, this includes formula derivations and numerical
              problems.In every chapter, you are provided with free lessons
              which would make your decision easier.
            </text>
            <Image className="imageClass" src={imgSrc} />
            <Image className="icon" src={homeIcon} />
          </div>
        </div>

        <div className="footer">
          <Text className="footerText">
            <div>
              <u2>
                <li>AG1 Campo Verde, Caranzalem, Goa 403002</li>
                <li>rajiv@pobox.com</li>
                <li>privacy policy</li>
              </u2>
            </div>
            <div>
              <u3>
                <br />
                <li />
                <li />
                <li>(91)-9822123618</li>
                <li>Home</li>
                <Breadcrumb.Item>Home</Breadcrumb.Item>
              </u3>
            </div>
          </Text>
        </div>
      </div>
    );
  }
}
//export default about;
