import React, { Component } from "react";
import "./Navigation.css";
import { StyleSheet, Text, View } from "react-native";
import Image from "react-bootstrap/Image";
import imgSrc from "./components/images/landingPage/intro.png";
import imgSrc1 from "./components/images/whyUsPage/whyUs_1.png";
import imgSrc2 from "./components/images/whyUsPage/whyUs_2.png";
import imgSrc3 from "./components/images/whyUsPage/whyUs_3.png";
import Dropdown from "react-bootstrap/Dropdown";
import "react-dropdown/style.css";
import { Nav, NavItem, Navbar, NavDropdown } from "react-bootstrap";
import { Link } from "react-router-dom";
//import { NavigationBar } from "./components/NavigationBar";
import about from "./components/About";
//import mysql from my;

import {
  BrowserRouter as Router,
  NavLink,
  Switch,
  Route
} from "react-router-dom";
import Breadcrumb from "react-bootstrap/Breadcrumb";
import { linkSync } from "fs";

//import console = require("console");

//import BreadcrumbsInit from "react-breadcrumbs";

//import "./classDropDown.js";

// import { BrowserRouter as Router, NavLink, Switch } from "react-router-dom";
//
// const express = require("express");
// const cors = require("cors");

//<Dropdown>
// <Dropdown.Toggle variant="success" id="dropdown-basic">
//  Dropdown Button
//</Dropdown.Toggle>

//<Dropdown.Menu>
// <Dropdown.Item href="#/action-1">Action</Dropdown.Item>
//<Dropdown.Item href="#/action-2">Another action</Dropdown.Item>
//<Dropdown.Item href="#/action-3">Something else</Dropdown.Item>
//</Dropdown.Menu>
//</Dropdown>;

var mysql = require("mysql");
var conn = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "12345",
  database: "vivaphysics"
});
//conn.connect();

class Navigation extends Component {
  render() {
    return (
      <div className="header_line" container>
        <div className="left_header">
          <h5>VivaPhysics</h5>
        </div>
        <div className="center_header">Rajiv Pilgaokar</div>
        <div className="right_header">
          <button> Login </button>
        </div>
        <div className="banner">
          <h1>A new,fun way to learn Physics</h1>

          <Text style={styles.textStyle}>
            Viva Physics brings to you an all new way of learning Physics <br />
            Concepts through animation and interaction.The lessons guide you{" "}
            <br />
            using a step by step approach, designed to bring concepts to life.
            <br />
            and make the whole experience of learning more enjoyable.
          </Text>
          <Image className="borderClass" src={imgSrc} />
          <hr color="#3ed8d8" />
        </div>
        <View style={styles.MainContainer}>
          <Text style={styles.textStyle2}>
            <b>WHY US?</b>
            <hr color="#3ed8d8" width="70" />
          </Text>

          <Dropdown>
            <Dropdown.Toggle id="dropdown-custom-1">Categories</Dropdown.Toggle>

            <Dropdown.Menu className="super-colors">
              <Dropdown.Item eventKey="1">part 1</Dropdown.Item>
              <Dropdown.Item href="#/action-2">part 2</Dropdown.Item>
            </Dropdown.Menu>
            <Router>
              <div>
                <Link to="/about">About</Link>;
                <Route exact path="/about" component={about} />;
                <Link to="/about">ABOUT</Link>
              </div>
            </Router>
          </Dropdown>
        </View>
        <imageR>
          <ul>
            <li>
              <Image className="imgClass" src={imgSrc1} roundedCircle />
            </li>
            <li>
              <Image className="imgClass" src={imgSrc2} roundedCircle />
            </li>
            <li>
              <Image className="imgClass" src={imgSrc3} roundedCircle />
            </li>
          </ul>
        </imageR>
        <View>
          <Text style={styles.textStyle5}>
            Learn faster using animation and explore
            <br /> concepts visually.
          </Text>
          <Text style={styles.textStyle6}>
            Strengthen your fundamentals using
            <br /> interactive modules.
          </Text>
          <Text style={styles.textStyle7}>
            A unique product that engages both the
            <br /> Teacher and the student.
          </Text>
        </View>
        <headerL>
          <View style={styles.MainContainer}>
            <Text style={styles.textStyle2}>
              <b>WHAT ARE OTHERS SAYING ABOUT US?</b>
              <hr color="#3ed8d8" width="50" />
            </Text>

            <Text style={styles.textStyle2}>
              <b> "Suddenly the classroom has become lot more energetic"</b>
              <hr color="#3ed8d8" width="120" borderStyle="dashed" />
            </Text>
          </View>
        </headerL>
        <View style={styles2.container}>
          <View style={styles2.toolbar}>
            <Text style={styles.textStyle}>VivaPhysics</Text>

            <Text style={styles.textStyle4}>
              <imageR>
                <u2>
                  <li>AG1 Campo Verde, Caranzalem, Goa 403002</li>
                  <li>rajiv@pobox.com</li>
                  <li>privacy policy</li>
                </u2>
              </imageR>
              <imageR>
                <u3>
                  <br />
                  <li />
                  <li />
                  <li>(91)-9822123618</li>
                  <li>Home</li>
                </u3>
              </imageR>
            </Text>
          </View>
        </View>
      </div>
    );
  }
}

export default Navigation;

const styles = StyleSheet.create({
  MainContainer: {
    justifyContent: "center",
    alignItems: "center",
    textAlign: "center",
    flex: 1
  },
  textStyle: {
    color: "#FFFFFF",
    width: "100%",
    height: 10,
    justifyContent: "left",
    textAlign: "left",
    margin: "10px"
  },
  textStyle2: {
    width: "80%",
    height: 50,
    justifyContent: "center",
    textAlign: "center"
  },
  textStyle4: {
    height: 15,
    color: "#FFFFFF"
  },
  textStyle5: {
    height: 50,
    justifyContent: "center",
    textAlign: "center",
    marginTop: "-15px",
    marginLeft: "-520px"
  },
  textStyle6: {
    height: 50,
    justifyContent: "center",
    textAlign: "center",
    marginTop: "-50px",
    marginLeft: "0px"
  },
  textStyle7: {
    height: 50,
    justifyContent: "center",
    textAlign: "center",
    marginTop: "-50px",
    marginLeft: "520px"
  },

  image: {
    margin: 1000,
    marginTop: -160
  }
});

const styles2 = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "white"
  },
  toolbar: {
    backgroundColor: "#333333",
    height: 110,
    width: 1350,
    marginLeft: 6,
    marginTop: 16,
    paddingBottom: "0px"
  },
  left: {
    marginTop: 30,
    fontSize: 14,
    textAlign: "center"
  },
  right: {
    marginTop: 30,
    fontSize: 14,
    textAlign: "center"
  },
  title: {
    marginTop: 30,
    flex: 1,
    fontSize: 14,
    textAlign: "center"
  },
  content: {
    backgroundColor: "#ffecff"
  }
});
