import React, { Component } from "react";
import Image from "react-bootstrap/Image";
import { Platform, StyleSheet, View, Text } from "react-native";
import imgSrc from "./images/landingPage/intro.png";
import imgA1 from "./images/whyUsPage/whyUs_2.png";
import imgA2 from "./images/whyUsPage/whyUs_1.png";
import imgA3 from "./images/whyUsPage/whyUs_3.png";
//import imgSrc from "C:/reactApp/counter-app/src/components/images/landingPage/intro.png";
//import { Divider } from 'react-native-elements';

export default class App extends Component {
  render() {
    return (
      <Text>
        <ul>
          <h1 style={myStyle}>
            This is Main Container View. A new, fun way to learn Physics
          </h1>
          <br />
          This is Main Container View. A new, fun way to learn Physics <br />
          <br />
        </ul>
      </Text>
    );
  }
}

var myStyle = {
  backgroundColor: "yellow",
  fontSize: 30,
  color: "#FF0000",
  outerHeight: 150
};
