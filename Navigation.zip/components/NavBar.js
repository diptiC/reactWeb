import React, { Component } from "react";
import { Link, NavLink } from "react-router-dom";

const NavBar = () => {
  return (
    <nav className="nav-wrapper red darken-3">
      <div className="container">
        <u1 className="right">
          <li>
            <NavLink to="/contact">Contact</NavLink>
          </li>
        </u1>
      </div>
    </nav>
  );
};
export default NavBar;
